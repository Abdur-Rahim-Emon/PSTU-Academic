*version 9.1 4118757391
u 30
V? 3
M? 2
R? 2
? 2
@libraries
@analysis
.DC 1 0 0 0 1 1
+ 0 0 Vgg
+ 0 4 0v
+ 0 5 5v
+ 0 6 0.01v
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 1728 
@status
n 0 125:00:20:21:48:55;1737388135 e 
s 2832 125:00:20:21:48:59;1737388139 e 
*page 1 0 970 720 iA
@ports
port 6 GND_EARTH 390 230 h
@parts
part 4 r 430 50 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
a 0 u 13 0 15 25 hln 100 VALUE=1
part 2 vdc 280 170 h
a 0 sp 0 0 22 37 hln 100 PART=vdc
a 0 x 0:13 0 0 0 hln 100 PKGREF=Vgg
a 1 xp 9 0 24 7 hcn 100 REFDES=Vgg
part 5 vdc 470 150 h
a 0 sp 0 0 22 37 hln 100 PART=vdc
a 1 u 13 0 -11 18 hcn 100 DC=20v
a 0 x 0:13 0 0 0 hln 100 PKGREF=Vdd
a 1 xp 9 0 24 7 hcn 100 REFDES=Vdd
part 3 irf150 360 120 h
a 0 sp 11 0 10 40 hcn 100 PART=irf150
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=M1
a 0 ap 9 0 5 10 hcn 100 REFDES=M1
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 300 95 hrn 100 PAGENO=1
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
part 29 nodeMarker 390 100 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=1
@conn
w 8
s 280 170 280 120 7
s 280 120 360 120 9
w 12
s 280 210 390 210 11
s 390 210 390 230 13
s 390 140 390 210 17
s 390 210 470 210 19
s 470 210 470 190 21
w 24
s 470 150 470 50 23
w 26
s 430 50 390 50 25
s 390 50 390 100 27
@junction
j 280 170
+ p 2 +
+ w 8
j 360 120
+ p 3 g
+ w 8
j 280 210
+ p 2 -
+ w 12
j 390 230
+ s 6
+ w 12
j 390 140
+ p 3 s
+ w 12
j 390 210
+ w 12
+ w 12
j 470 190
+ p 5 -
+ w 12
j 470 50
+ p 4 2
+ w 24
j 470 150
+ p 5 +
+ w 24
j 430 50
+ p 4 1
+ w 26
j 390 100
+ p 3 d
+ w 26
j 390 100
+ p 29 pin1
+ p 3 d
j 390 100
+ p 29 pin1
+ w 26
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
