*version 9.1 529885938
u 37
V? 2
D? 5
R? 2
? 2
@libraries
@analysis
.TRAN 1 0 0 0
+0 0ns
+1 100ms
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 2712 
@status
n 0 125:00:20:21:40:36;1737387636 e 
s 2832 125:00:20:21:40:39;1737387639 e 
*page 1 0 970 720 iA
@ports
port 2 GND_EARTH 400 300 h
@parts
part 5 D1N4002 400 170 u
a 0 sp 11 0 17 29 hln 100 PART=D1N4002
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DO-41
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=D2
a 0 ap 9 0 17 4 hln 100 REFDES=D2
part 7 D1N4002 370 90 h
a 0 sp 11 0 17 29 hln 100 PART=D1N4002
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DO-41
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=D4
a 0 ap 9 0 17 -6 hln 100 REFDES=D4
part 6 D1N4002 510 170 h
a 0 sp 11 0 17 29 hln 100 PART=D1N4002
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DO-41
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=D3
a 0 ap 9 0 17 4 hln 100 REFDES=D3
part 4 D1N4002 540 90 u
a 0 sp 11 0 17 29 hln 100 PART=D1N4002
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DO-41
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=D1
a 0 ap 9 0 17 4 hln 100 REFDES=D1
part 8 r 440 130 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
part 3 vsin 230 220 h
a 0 a 0:13 0 0 0 hln 100 PKGREF=V1
a 1 ap 9 0 20 10 hcn 100 REFDES=V1
a 1 u 0 0 0 0 hcn 100 DC=0v
a 1 u 0 0 0 0 hcn 100 AC=0v
a 1 u 0 0 0 0 hcn 100 VOFF=0v
a 1 u 0 0 0 0 hcn 100 VAMPL=12v
a 1 u 0 0 0 0 hcn 100 FREQ=100hz
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 300 95 hrn 100 PAGENO=1
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
part 36 nodeMarker 440 90 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=1
@conn
w 20
a 0 up 0:33 0 0 0 hln 100 V=
s 230 220 370 220 19
a 0 up 33 0 300 219 hct 100 V=
s 370 90 370 170 15
s 370 220 370 170 21
w 24
a 0 up 0:33 0 0 0 hln 100 V=
s 230 260 400 260 23
a 0 up 33 0 315 259 hct 100 V=
s 540 90 540 170 17
s 540 260 540 170 25
s 400 260 540 260 29
s 400 300 400 260 27
w 12
a 0 up 0:33 0 0 0 hln 100 V=
s 400 170 480 170 11
a 0 up 33 0 440 169 hct 100 V=
s 480 170 510 170 35
s 480 130 480 170 33
w 10
a 0 up 0:33 0 0 0 hln 100 V=
s 400 90 440 90 9
s 440 90 510 90 32
a 0 up 33 0 475 89 hct 100 V=
s 440 90 440 130 30
@junction
j 510 90
+ p 4 2
+ w 10
j 400 90
+ p 7 2
+ w 10
j 400 170
+ p 5 1
+ w 12
j 510 170
+ p 6 1
+ w 12
j 230 220
+ p 3 +
+ w 20
j 370 90
+ p 7 1
+ w 20
j 370 170
+ p 5 2
+ w 20
j 230 260
+ p 3 -
+ w 24
j 540 90
+ p 4 1
+ w 24
j 540 170
+ p 6 2
+ w 24
j 400 300
+ s 2
+ w 24
j 400 260
+ w 24
+ w 24
j 440 130
+ p 8 1
+ w 10
j 440 90
+ w 10
+ w 10
j 480 130
+ p 8 2
+ w 12
j 480 170
+ w 12
+ w 12
j 440 90
+ p 36 pin1
+ w 10
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
