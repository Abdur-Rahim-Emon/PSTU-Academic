*version 9.1 3413657463
u 118
Q? 2
I? 4
V? 5
R? 4
? 4
@libraries
@analysis
.DC 1 1 0 0 0 0
+ 0 0 Vcb
+ 0 4 -0.2
+ 0 5 20
+ 0 6 0.001
+ 1 0 Vbe
+ 1 4 0
+ 1 5 5
+ 1 6 1
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 2573 
@status
n 0 125:00:20:18:33:33;1737376413 e 
s 0 125:00:20:18:33:39;1737376419 e 
*page 1 0 970 720 iA
@ports
port 3 GND_EARTH 400 310 h
a 1 s 0 0 10 28 hcn 100 LABEL=0
@parts
part 2 Q2N2222 400 220 v
a 0 sp 11 0 25 40 hln 100 PART=Q2N2222
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-18
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=Q1
a 0 ap 9 0 5 5 hln 100 REFDES=Q1
part 5 VDC 270 240 h
a 0 sp 0 0 22 37 hln 100 PART=VDC
a 0 x 0:13 0 0 0 hln 100 PKGREF=Vcb
a 1 xp 9 0 24 7 hcn 100 REFDES=Vcb
part 73 r 300 200 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R2
a 0 ap 9 0 15 0 hln 100 REFDES=R2
a 0 u 13 0 15 25 hln 100 VALUE=100
part 93 vdc 570 280 u
a 0 sp 0 0 22 37 hln 100 PART=vdc
a 0 x 0:13 0 0 0 hln 100 PKGREF=Vbe
a 1 xp 9 0 24 7 hcn 100 REFDES=Vbe
part 76 r 480 200 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100
a 0 x 0:13 0 0 0 hln 100 PKGREF=R1
a 0 xp 9 0 15 0 hln 100 REFDES=R1
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 300 95 hrn 100 PAGENO=1
part 94 nodeMarker 350 200 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=Q1:c
a 0 a 0 0 4 22 hlb 100 LABEL=2
part 96 nodeMarker 440 200 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=Q1:e
a 0 a 0 0 4 22 hlb 100 LABEL=3
@conn
w 85
a 0 up 0:33 0 0 0 hln 100 V=
s 270 240 270 200 6
a 0 up 33 0 272 220 hlt 100 V=
s 270 200 300 200 72
w 104
a 0 up 0:33 0 0 0 hln 100 V=
s 400 220 400 310 16
s 270 310 400 310 12
s 270 280 270 310 10
s 400 310 570 310 18
a 0 up 33 0 485 309 hct 100 V=
s 570 310 570 280 20
w 92
a 0 up 0:33 0 0 0 hln 100 V=
s 570 240 570 200 22
s 570 200 520 200 24
a 0 up 33 0 545 199 hct 100 V=
w 67
a 0 up 0:33 0 0 0 hln 100 V=
s 340 200 350 200 74
s 350 200 380 200 108
a 0 up 33 0 365 199 hct 100 V=
w 23
a 0 up 0:33 0 0 0 hln 100 V=
s 480 200 440 200 78
a 0 up 33 0 460 199 hct 100 V=
s 440 200 420 200 109
@junction
j 420 200
+ p 2 e
+ w 23
j 480 200
+ p 76 1
+ w 23
j 520 200
+ p 76 2
+ w 92
j 440 200
+ p 96 pin1
+ w 23
j 270 240
+ p 5 +
+ w 85
j 400 220
+ p 2 b
+ w 104
j 400 310
+ s 3
+ w 104
j 270 280
+ p 5 -
+ w 104
j 380 200
+ p 2 c
+ w 67
j 350 200
+ p 94 pin1
+ w 67
j 340 200
+ p 73 2
+ w 67
j 300 200
+ p 73 1
+ w 85
j 570 240
+ p 93 -
+ w 92
j 570 280
+ p 93 +
+ w 104
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
