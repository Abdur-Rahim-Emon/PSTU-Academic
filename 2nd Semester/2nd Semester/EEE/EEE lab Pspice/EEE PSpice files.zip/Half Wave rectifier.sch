*version 9.1 3133119657
u 42
V? 2
D? 2
R? 4
? 4
@libraries
@analysis
.TRAN 1 0 0 0
+0 0ns
+1 5ms
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 1834 
@status
n 0 125:00:20:23:18:06;1737393486 e 
s 2832 125:00:20:23:18:06;1737393486 e 
*page 1 0 970 720 iA
@ports
port 39 GND_EARTH 470 270 h
port 41 GND_EARTH 470 270 h
@parts
part 5 r 590 210 d
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R2
a 0 ap 9 0 15 0 hln 100 REFDES=R2
part 3 D1N4002 450 150 h
a 0 sp 11 0 17 29 hln 100 PART=D1N4002
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DO-41
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=D1
a 0 ap 9 0 17 4 hln 100 REFDES=D1
part 2 VSIN 330 200 h
a 0 a 0:13 0 0 0 hln 100 PKGREF=V1
a 1 ap 9 0 20 10 hcn 100 REFDES=V1
a 1 u 0 0 0 0 hcn 100 DC=0
a 1 u 0 0 0 0 hcn 100 AC=0
a 1 u 0 0 0 0 hcn 100 VOFF=0
a 1 u 0 0 0 0 hcn 100 VAMPL=20
a 1 u 0 0 0 0 hcn 100 FREQ=1k
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 300 95 hrn 100 PAGENO=1
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
part 36 nodeMarker 330 150 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=1
part 37 nodeMarker 590 150 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=2
part 38 nodeMarker 590 150 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=3
@conn
w 30
s 330 200 330 150 9
s 330 150 450 150 33
w 8
s 480 150 590 150 15
s 590 150 590 210 16
w 22
s 330 240 330 270 23
s 330 270 470 270 24
s 590 270 590 250 26
s 470 270 590 270 40
@junction
j 330 240
+ p 2 -
+ w 22
j 590 250
+ p 5 2
+ w 22
j 330 200
+ p 2 +
+ w 30
j 480 150
+ p 3 2
+ w 8
j 590 210
+ p 5 1
+ w 8
j 450 150
+ p 3 1
+ w 30
j 330 150
+ p 36 pin1
+ w 30
j 590 150
+ p 37 pin1
+ w 8
j 590 150
+ p 38 pin1
+ w 8
j 470 270
+ s 39
+ w 22
j 470 270
+ s 41
+ s 39
j 470 270
+ s 41
+ w 22
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
