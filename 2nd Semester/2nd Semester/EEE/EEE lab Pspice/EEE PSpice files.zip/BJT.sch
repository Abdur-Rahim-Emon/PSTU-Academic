*version 9.1 734389774
u 39
Q? 2
I? 5
V? 3
? 5
@libraries
@analysis
.DC 1 1 2 2 0 1
+ 0 0 IB
+ 0 4 100u
+ 0 5 1mA
+ 0 6 20
+ 1 0 IB
+ 1 4 -25
+ 1 5 25
+ 1 6 125
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 1639 
@status
n 0 125:00:20:19:29:57;1737379797 e 
s 2832 125:00:20:19:29:57;1737379797 e 
*page 1 0 970 720 iA
@ports
port 2 GND_EARTH 430 180 h
@parts
part 32 IDC 380 170 u
a 0 x 0:13 0 0 0 hln 100 PKGREF=IB
a 1 xp 9 0 20 10 hcn 100 REFDES=IB
a 0 sp 11 0 0 50 hln 100 PART=IDC
part 3 Q2N2222 410 100 h
a 0 sp 11 0 25 40 hln 100 PART=Q2N2222
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-18
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=Q1
a 0 ap 9 0 5 5 hln 100 REFDES=Q1
part 5 VDC 520 120 h
a 0 sp 0 0 22 37 hln 100 PART=VDC
a 0 x 0:13 0 0 0 hln 100 PKGREF=Vce
a 1 xp 9 0 24 7 hcn 100 REFDES=Vce
a 1 u 13 0 -11 18 hcn 100 DC=5v
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 300 95 hrn 100 PAGENO=1
part 38 iMarker 430 80 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 6 20 hlb 100 LABEL=4
@conn
w 7
a 0 up 0:33 0 0 0 hln 100 V=
s 380 130 380 100 6
s 380 100 410 100 8
a 0 up 33 0 395 99 hct 100 V=
w 30
a 0 up 0:33 0 0 0 hln 100 V=
s 520 180 430 180 18
a 0 up 33 0 475 179 hct 100 V=
s 430 120 430 180 20
s 520 160 520 180 16
s 430 180 380 180 22
s 380 180 380 170 24
w 11
a 0 up 0:33 0 0 0 hln 100 V=
s 430 80 430 50 10
s 430 50 520 50 12
a 0 up 33 0 475 49 hct 100 V=
s 520 50 520 120 14
@junction
j 520 120
+ p 5 +
+ w 11
j 430 80
+ p 3 c
+ w 11
j 430 120
+ p 3 e
+ w 30
j 410 100
+ p 3 b
+ w 7
j 380 130
+ p 32 -
+ w 7
j 380 170
+ p 32 +
+ w 30
j 430 180
+ s 2
+ w 30
j 520 160
+ p 5 -
+ w 30
j 430 80
+ p 38 pin1
+ p 3 c
j 430 80
+ p 38 pin1
+ w 11
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
