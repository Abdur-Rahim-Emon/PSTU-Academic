*version 9.1 1250497842
u 51
Q? 7
V? 2
R? 6
@libraries
@analysis
.TEMP 1 27
.OP 1 
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 2632 
@status
n 0 125:00:20:19:24:18;1737379458 e 
s 2832 125:00:20:19:24:18;1737379458 e 
*page 1 0 970 720 iA
@ports
port 8 GND_EARTH 460 380 h
port 35 GND_EARTH 580 160 h
@parts
part 6 r 340 310 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R2
a 0 xp 9 0 15 0 hln 100 REFDES=R2
a 0 u 13 0 10 40 hln 100 VALUE=22K
part 4 r 460 140 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=RC
a 0 xp 9 0 15 0 hln 100 REFDES=RC
a 0 u 13 0 10 40 hln 100 VALUE=3.3K
part 3 vdc 580 120 h
a 0 sp 0 0 22 37 hln 100 PART=vdc
a 1 u 13 0 -11 18 hcn 100 DC=10V
a 0 x 0:13 0 0 0 hln 100 PKGREF=VCC
a 1 xp 9 0 24 7 hcn 100 REFDES=VCC
part 40 r 460 310 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 35 hln 100 VALUE=2.2k
a 0 x 0:13 0 0 0 hln 100 PKGREF=RE
a 0 xp 9 0 15 0 hln 100 REFDES=RE
part 5 r 340 140 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R1
a 0 xp 9 0 15 0 hln 100 REFDES=R1
a 0 u 13 0 15 40 hln 100 VALUE=57k
part 50 Q2N2222 440 200 h
a 0 sp 11 0 25 40 hln 100 PART=Q2N2222
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-18
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=Q6
a 0 ap 9 0 5 5 hln 100 REFDES=Q6
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 300 95 hrn 100 PAGENO=1
@conn
w 28
a 0 up 0:33 0 0 0 hln 100 V=
s 340 100 460 100 27
s 460 100 580 100 31
a 0 up 33 0 520 99 hct 100 V=
s 580 100 580 120 33
w 12
a 0 up 0:33 0 0 0 hln 100 V=
s 460 380 340 380 13
a 0 up 33 0 400 379 hct 100 V=
s 340 380 340 310 15
s 460 310 460 380 42
w 30
a 0 up 0:33 0 0 0 hln 100 V=
s 460 140 460 180 29
a 0 up 33 0 462 155 hlt 100 V=
w 49
a 0 up 0:33 0 0 0 hln 100 V=
s 460 220 460 270 9
a 0 up 33 0 462 255 hlt 100 V=
w 18
a 0 up 0:33 0 0 0 hln 100 V=
s 340 270 340 200 17
s 340 200 440 200 19
a 0 up 33 0 390 199 hct 100 V=
s 340 200 340 140 23
@junction
j 460 380
+ s 8
+ w 12
j 340 310
+ p 6 1
+ w 12
j 340 270
+ p 6 2
+ w 18
j 340 200
+ w 18
+ w 18
j 340 140
+ p 5 1
+ w 18
j 340 100
+ p 5 2
+ w 28
j 580 120
+ p 3 +
+ w 28
j 580 160
+ s 35
+ p 3 -
j 460 100
+ p 4 2
+ w 28
j 460 140
+ p 4 1
+ w 30
j 460 310
+ p 40 1
+ w 12
j 460 270
+ p 40 2
+ w 49
j 460 180
+ p 50 c
+ w 30
j 460 220
+ p 50 e
+ w 49
j 440 200
+ p 50 b
+ w 18
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
