*version 9.1 134855498
u 46
V? 3
M? 3
R? 2
? 2
@libraries
@analysis
.DC 1 0 0 0 1 1
+ 0 0 Vgg
+ 0 4 0
+ 0 5 10
+ 0 6 0.01
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 2196 
@status
n 0 125:00:20:21:56:38;1737388598 e 
s 2832 125:00:20:21:56:42;1737388602 e 
*page 1 0 970 720 iA
@ports
port 6 GND_EARTH 410 210 h
@parts
part 2 vdc 220 90 h
a 0 sp 0 0 22 37 hln 100 PART=vdc
a 0 x 0:13 0 0 0 hln 100 PKGREF=Vgg
a 1 xp 9 0 24 7 hcn 100 REFDES=Vgg
part 4 irf150 380 150 h
a 0 sp 11 0 10 40 hcn 100 PART=irf150
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=M1
a 0 ap 9 0 5 10 hcn 100 REFDES=M1
part 5 irf9140 380 40 h
a 0 sp 11 0 10 40 hcn 100 PART=irf9140
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-204AA
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=M2
a 0 ap 9 0 5 10 hcn 100 REFDES=M2
part 7 r 490 170 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
a 0 u 13 0 15 25 hln 100 VALUE=100k
part 3 vdc 610 110 h
a 0 sp 0 0 22 37 hln 100 PART=vdc
a 0 x 0:13 0 0 0 hln 100 PKGREF=Vdd
a 1 xp 9 0 24 7 hcn 100 REFDES=Vdd
a 1 u 13 0 -11 18 hcn 100 DC=10V
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 300 95 hrn 100 PAGENO=1
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
part 45 nodeMarker 490 90 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=1
@conn
w 9
s 220 130 220 200 8
s 220 200 410 200 10
s 410 200 410 210 12
s 410 200 410 170 14
s 410 200 490 200 16
s 490 200 490 170 18
s 490 170 610 170 20
s 610 170 610 150 22
w 29
s 220 90 320 90 28
s 320 90 320 150 30
s 320 150 380 150 32
s 320 90 320 40 34
s 320 40 380 40 36
w 25
s 610 110 610 20 24
s 610 20 410 20 26
w 39
s 410 60 410 90 38
s 410 90 410 130 42
s 410 90 490 90 40
s 490 90 490 130 43
@junction
j 220 130
+ p 2 -
+ w 9
j 410 210
+ s 6
+ w 9
j 410 170
+ p 4 s
+ w 9
j 410 200
+ w 9
+ w 9
j 490 170
+ p 7 1
+ w 9
j 610 150
+ p 3 -
+ w 9
j 610 110
+ p 3 +
+ w 25
j 220 90
+ p 2 +
+ w 29
j 380 150
+ p 4 g
+ w 29
j 320 90
+ w 29
+ w 29
j 410 20
+ p 5 d
+ w 25
j 380 40
+ p 5 g
+ w 29
j 410 130
+ p 4 d
+ w 39
j 410 60
+ p 5 s
+ w 39
j 410 90
+ w 39
+ w 39
j 490 130
+ p 7 2
+ w 39
j 490 90
+ p 45 pin1
+ w 39
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
