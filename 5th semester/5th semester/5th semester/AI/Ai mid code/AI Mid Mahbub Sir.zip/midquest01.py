import itertools
import re

# -----------------------------
# Logical operations
# -----------------------------
def AND(p, q): return p and q
def OR(p, q): return p or q
def NOT(p): return not p
def IMPLIES(p, q): return (not p) or q
def IFF(p, q): return p == q

# -----------------------------
# EASY + SYMBOL NORMALIZER
# -----------------------------
def normalize(expr):
    expr = expr.lower()

    # English words → operators
    expr = expr.replace('implies', ' IMPLIES ')
    expr = expr.replace('iff', ' IFF ')
    expr = expr.replace('and', ' AND ')
    expr = expr.replace('or', ' OR ')
    expr = expr.replace('not', ' NOT ')

    # Symbol support (optional)
    expr = expr.replace('<->', ' IFF ')
    expr = expr.replace('->', ' IMPLIES ')
    expr = expr.replace('&&', ' AND ')
    expr = expr.replace('||', ' OR ')
    expr = expr.replace('!', ' NOT ')

    return expr

# -----------------------------
# Tokenizer
# -----------------------------
def tokenize(expr):
    expr = expr.replace('(', ' ( ').replace(')', ' ) ')
    return expr.split()

# -----------------------------
# Precedence
# -----------------------------
precedence = {
    'NOT': 3,
    'AND': 2,
    'OR': 1,
    'IMPLIES': 0,
    'IFF': 0
}

# -----------------------------
# Infix → Postfix
# -----------------------------
def infix_to_postfix(tokens):
    output = []
    stack = []

    for token in tokens:
        if re.match(r'^[a-z]$', token):
            output.append(token)

        elif token == '(':
            stack.append(token)

        elif token == ')':
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            stack.pop()

        else:
            while (stack and stack[-1] != '(' and
                   precedence.get(stack[-1], -1) >= precedence.get(token, -1)):
                output.append(stack.pop())
            stack.append(token)

    while stack:
        output.append(stack.pop())

    return output

# -----------------------------
# SAFE Postfix Evaluation
# -----------------------------
def evaluate_postfix(postfix, values):
    stack = []

    for token in postfix:

        if token in values:
            stack.append(values[token])

        elif token == 'NOT':
            if not stack:
                raise ValueError("NOT missing operand")
            stack.append(NOT(stack.pop()))

        else:
            if len(stack) < 2:
                raise ValueError(f"Invalid expression near '{token}'")

            b = stack.pop()
            a = stack.pop()

            if token == 'AND':
                stack.append(AND(a, b))
            elif token == 'OR':
                stack.append(OR(a, b))
            elif token == 'IMPLIES':
                stack.append(IMPLIES(a, b))
            elif token == 'IFF':
                stack.append(IFF(a, b))

    if len(stack) != 1:
        raise ValueError("Invalid expression structure")

    return stack[0]

# -----------------------------
# Truth Table Generator
# -----------------------------
def truth_table(expr):
    expr = normalize(expr)
    tokens = tokenize(expr)
    postfix = infix_to_postfix(tokens)

    variables = sorted(set([t for t in tokens if re.match(r'^[a-z]$', t)]))

    print("\nExpression:", expr)
    print(" | ".join(variables) + " | Result")
    print("-" * (len(variables) * 6 + 10))

    results = []

    for values in itertools.product([False, True], repeat=len(variables)):
        val_dict = dict(zip(variables, values))
        result = evaluate_postfix(postfix, val_dict)
        results.append(result)

        row = " | ".join(str(val_dict[v]) for v in variables)
        print(row + " | " + str(result))

    if all(results):
        print("\n Tautology")
    elif not any(results):
        print("\n Contradiction")
    else:
        print("\n Contingent")

# -----------------------------
# MAIN
# -----------------------------
expr = input("Enter expression (use: and, or, not, implies, iff OR symbols):\n")
truth_table(expr)