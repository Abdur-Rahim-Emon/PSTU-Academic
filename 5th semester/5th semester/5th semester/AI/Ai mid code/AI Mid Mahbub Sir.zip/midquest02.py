from itertools import product

# -------- logic functions --------
def AND(p, q): return p and q
def OR(p, q): return p or q
def IMPLIES(p, q): return (not p) or q
def IFF(p, q): return p == q

# -------- parser --------
def parse_statement(sentence):
    s = sentence.lower()

    if "if and only if" in s or "iff" in s:
        return IFF, "p <-> q (biconditional)"

    elif "if" in s and "then" in s:
        return IMPLIES, "p -> q (implication)"

    elif "and" in s:
        return AND, "p ∧ q (AND)"

    elif "or" in s:
        return OR, "p ∨ q (OR)"

    else:
        return None, "Unknown statement"

# -------- truth table printer --------
def print_truth_table(func, name):
    print(f"\nTruth Table for: {name}")
    print("p | q | Result")
    print("----------------")

    for p, q in product([True, False], repeat=2):
        print(f"{p} | {q} | {func(p, q)}")

# -------- main --------
sentence = input("Enter a logical sentence: ")

func, name = parse_statement(sentence)

if func is None:
    print("Could not understand the statement.")
else:
    print_truth_table(func, sentence)